<?php

define("DB_HOST", "LOCALHOST");
define("DB_USER", "uzzaorti_test");
define("DB_PASS", "Zt9T2i]QWKDn");
define("DB_NAME", "uzzaorti_test");