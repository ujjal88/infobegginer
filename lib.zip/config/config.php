<?php
define("DB_HOST", "localhost");
define("DB_USER", "uzzaorti_test");
define("DB_PASS", "Zt9T2i]QWKDn");
define("DB_NAME", "uzzaorti_test");
define("TITLE", "Web Design and Development ");

