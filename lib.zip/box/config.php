<?php
define("DB_HOST", "localhost");
define("DB_USER", "uzzaorti_box1");
define("DB_PASS", "b!QeJ1{]d~+s");
define("DB_NAME", "uzzaorti_box1")




